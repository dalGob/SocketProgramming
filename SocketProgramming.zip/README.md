### SocketProgramming

Assignment 3 For CSCI 3171 - Network Programming

### Group Members
<ul> 
<li> Gobind Singh - Server Code and Game Logic     
<li> Parth Patel - Client Code
</ul>

### Steps to execute the program 

##### Prerequisites
Make sure you have java compiler on your local machine

##### How to execute code through the terminal

*Execute the commands on two different terminals*

```
java Server.java  //This will run the server
```

```
java Client.java //This will run the client
```

